USE [master]
GO

/****** Object:  Database [travel.com.vn]    Script Date: 07/06/2017 13:17:52 ******/
IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'travel.com.vn')
DROP DATABASE [travel.com.vn]
GO

